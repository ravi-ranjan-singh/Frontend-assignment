const api = {
  urlGet: 'https://profiler-ravi.herokuapp.com/user?email=',
  urlPost: 'https://profiler-ravi.herokuapp.com/',
  headers: {
    'Content-Type': 'application/json'
  }
};

export default api;
